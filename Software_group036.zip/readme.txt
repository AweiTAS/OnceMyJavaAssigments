This file is about to teach you how to start this program.
/**
 * 
 * @author group036
 * @version 1.0
 */
Make sure all resource codes in their correctly named folders
SSS:
	.classpath, .project
	file:
	    info.txt, station.txt.( make sure they are exist)( make sure they are exist!)( MAKE SURE THEY ARE EXIST!)
	    usage: 
	        [txt file named as customer's qmnumber]
	src:
	    Boundary: 
	        Charge, FrameInitiation, Login, MainFrame, ManagerMain, Register, RunningProgress, SlotPanel, StationPanel, SuccessPanel, UsagePanel, UsageSearchPanel, UserMain
	    Entity: 
	        Station, User
	    Operation: 
	        BackendLogic, FileOperation, Report, SendMail, StationControl, TimeControl

You have 2 options to start the project.
Option1( using eclipse or other IDE):
    1. Import this folder SSS as project folder.
    2. Run RunningProgress.java to start the system.

Option2( using cmd):
    1. make sure your current folder is SSS\src>
    2. type in "javac .\Boundary\*.java" in cmd
    3. type in "javac .\Entity\*.java" in cmd
    4. type in "javac .\Operation\*.java" in cmd
    5. type in "cd Boundary" in cmd
    6. type in "java RunningProgress" in cmd