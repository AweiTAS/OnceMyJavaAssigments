the runnable file of this bank system is Test.class in BankSys package

1. run Test.class in cmd or eclipse
2. type in addCustomer command to add the first customer. For example, "addCustomer awei bupt 19980122 2 123123456 70", which will try to add a customer named "awei", live in "bupt", born in "1998.01.22", first account type is junior(2)(current(1) or saver(3)), PIN will be cut to "123456", and save 70$ at first. But it will be faliure because this customer is too old to open a junior account.
3. type in "getC awei" command to get into the interface of customer awei.
4. type in "saver" command to get into the interface of customer awei's saver account, if exist.
5. type in "withdraw" command to withdraw money.
6. you can always type in a incorrect command to get help of current command interface