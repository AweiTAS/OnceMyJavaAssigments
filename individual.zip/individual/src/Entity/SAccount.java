package Entity;
/**
 * Saver account
 * @author awei
 *
 */
public class SAccount extends Account{
	
	SAccount(BankSystem s, float balance, String possessed, int absolute){
		super(s, balance, possessed, absolute);
		this.suspendFlag = true;
		this.type = 1;
	}
	
	public float withdraw(float funds, long PIN){
		if(this.suspendFlag) {
			if (system.verify(this.ANumber, PIN)){
				System.out.println("verify for withdrawing succeed!");
				if (funds != -1) {
					System.out.println("\n\nIt's a minimum period of notice (in days)");
					System.out.println("press enter to contiune\n\n");
					try {System.in.read();}catch(Exception e){}
					if(funds <= balance) {
						balance -= funds;
						System.out.println("account: " + ANumber + " have " + balance + " balance left");
						return balance;
					}
					System.out.println("not enough! " + ANumber + " have " + balance + " balance left");
					return balance;
				}
				balance = 0;
				System.out.println("cleard!");
				return 0;
			}
			System.out.println("falied when checking account number with PIN!");
			return balance;
		}else {
			System.out.println("Suspended!");
		}
		return balance;
	}
}
