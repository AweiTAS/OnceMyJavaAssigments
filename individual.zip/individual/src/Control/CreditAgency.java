package Control;

import Entity.*;
/**
 * Used to check customer's credit status
 * @author awei
 *
 */
public class CreditAgency {
	public static boolean searchCredit(Customer c){
		return true;
	}
}
